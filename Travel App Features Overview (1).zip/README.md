
  # Travel App Features Overview

  This is a code bundle for Travel App Features Overview. The original project is available at https://www.figma.com/design/viKs5a5xz3oEnu5vokdbhi/Travel-App-Features-Overview.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  